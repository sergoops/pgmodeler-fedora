---
name: Feature request / improvement
about: Give your suggestions for improvements to this project.

---

**Feature description**
_A clear and concise description of what the problem is._

**Sample image**
_If the feature requested is a visual improvement, please, attach some images to make it clear._

**Additional info**
_Add any other context or screenshots about the feature request here._
